library(shiny)

runGitHub("stat133-hws-fall17", "Ceciliali1998", subdir = "hw04/app")

#Note: Reflection Questions are in gradevis.R in app
