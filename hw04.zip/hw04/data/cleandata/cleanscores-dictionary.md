
## Data `rawscores-dictionary.csv`

Here's the description of the csv objects in `rawscores-dictionary.csv`:

- `HW1`: score of homework1, total of 100pts
- `HW2`: score of homework2, total of 100pts
- `HW3`: score of homework3, total of 100pts
- `HW4`: score of homework4, total of 100pts
- `HW5`: score of homework5, total of 100pts
- `HW6`: score of homework6, total of 100pts
- `HW7`: score of homework7, total of 100pts
- `HW8`: score of homework8, total of 100pts
- `HW9`: score of homework9, total of 100pts
- `ATT`: numer of attended labs, 0 to 12
- `QZ1`: score of quiz1, total of 12 pts
- `QZ2`: score of quiz2, total of 18 pts
- `QZ3`: score of quiz3, total of 20 pts
- `QZ4`: score of quiz4, total of 20 pts
- `EX1`: score of exam1, total of 80 pts
- `EX2`: score of exam1, total of 90 pts
- `Test1`: rescaled score of exam1
- `Test2`: rescaled score of exam2
- `Homework`: score of homeworks, lowest score dopped
- `Quiz`: score of quizzes, lowest score dopped
- `Overall`: overall score
- `Grade`: letter grade





The data is from https://raw.githubusercontent.com/ucb-stat133/stat133-fall-2017/master/data/rawscores.csv


